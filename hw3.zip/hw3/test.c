#include "stdio.h"
#include "stdlib.h"
#include "math.h"

int main (int argc, char *argv[]) {

    int n = 1000;
    double sqrtn = sqrt(n);

    printf("sqrt(1000) = %f\n", sqrtn);

    return 0;

}