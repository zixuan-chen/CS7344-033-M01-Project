make sure the mpi is correctly installed
to check project2, please run gen_matrix.py to get the matrix data
to check project3, please put data in the following way
./big_file/big_100.txt
./small_file/small_xxx.txt

run "./run.sh" to get the result